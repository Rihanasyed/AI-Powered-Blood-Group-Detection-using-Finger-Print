
-- Each user can upload/read/delete only files inside fingerprints/{their-user-id}/...
CREATE POLICY "Users read their own fingerprints"
ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'fingerprints' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users upload their own fingerprints"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'fingerprints' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users delete their own fingerprints"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'fingerprints' AND auth.uid()::text = (storage.foldername(name))[1]);
