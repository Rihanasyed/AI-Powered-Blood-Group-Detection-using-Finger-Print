import { createFileRoute, Link } from "@tanstack/react-router";
import { Mail, MessageCircle } from "lucide-react";
import { Logo } from "@/components/Logo";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Fingerprint-Based Blood Group Detection System" },
      { name: "description", content: "Get in touch with the BloodScan AI team." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  return (
    <div className="min-h-screen bg-hero text-foreground">
      <header className="mx-auto flex max-w-5xl items-center justify-between px-6 py-6">
        <Link to="/"><Logo /></Link>
        <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">← Home</Link>
      </header>
      <main className="mx-auto max-w-2xl px-6 py-12">
        <h1 className="font-display text-4xl">Contact us</h1>
        <p className="mt-4 text-muted-foreground">
          Questions, research collaboration, or feedback on BloodScan AI? Reach out — we'd love
          to hear from you.
        </p>
        <div className="mt-10 space-y-4">
          <a
            href="mailto:team@bloodscan.ai"
            className="flex items-center gap-3 rounded-xl border border-border bg-card/60 p-5 hover:border-primary/50"
          >
            <Mail className="h-5 w-5 text-primary" />
            <div>
              <div className="font-medium">Email</div>
              <div className="text-sm text-muted-foreground">team@bloodscan.ai</div>
            </div>
          </a>
          <div className="flex items-center gap-3 rounded-xl border border-border bg-card/60 p-5">
            <MessageCircle className="h-5 w-5 text-primary" />
            <div>
              <div className="font-medium">In-app chatbot</div>
              <div className="text-sm text-muted-foreground">
                BloodScan AI Assistant — available inside the app after sign in.
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
