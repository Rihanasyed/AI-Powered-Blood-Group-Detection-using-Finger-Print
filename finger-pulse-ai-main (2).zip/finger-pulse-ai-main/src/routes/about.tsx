import { createFileRoute, Link } from "@tanstack/react-router";
import { Logo } from "@/components/Logo";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — Fingerprint-Based Blood Group Detection System" },
      {
        name: "description",
        content:
          "Learn how the Fingerprint-Based Blood Group Detection System uses BloodScan AI to predict ABO/Rh blood groups from fingerprint patterns.",
      },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <div className="min-h-screen bg-hero text-foreground">
      <header className="mx-auto flex max-w-5xl items-center justify-between px-6 py-6">
        <Link to="/"><Logo /></Link>
        <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">← Home</Link>
      </header>
      <main className="mx-auto max-w-3xl px-6 py-12">
        <h1 className="font-display text-4xl">About the project</h1>
        <p className="mt-4 text-muted-foreground">
          The Fingerprint-Based Blood Group Detection System is a research-driven platform that
          uses <strong>BloodScan AI</strong> — a hybrid KNN + MDSVM machine learning engine — to
          predict ABO and Rh blood groups directly from fingerprint ridge patterns.
        </p>
        <h2 className="mt-10 font-display text-2xl">Our mission</h2>
        <p className="mt-3 text-muted-foreground">
          Make blood-group screening fast, non-invasive and accessible — supporting medical
          research, education, and emergency triage scenarios where traditional serological tests
          are impractical.
        </p>
        <h2 className="mt-10 font-display text-2xl">How it works</h2>
        <ol className="mt-3 list-decimal space-y-2 pl-6 text-muted-foreground">
          <li>Capture a fingerprint via upload or live camera scan.</li>
          <li>Image enhancement and ridge extraction.</li>
          <li>Feature extraction fed to KNN + MDSVM ensemble.</li>
          <li>Ensemble decision produces a blood group with confidence score.</li>
        </ol>
        <p className="mt-10 text-xs text-muted-foreground">
          For research and educational use only — not a substitute for clinical blood typing.
        </p>
      </main>
    </div>
  );
}
