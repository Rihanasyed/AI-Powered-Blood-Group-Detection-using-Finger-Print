import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/ComingSoon";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin — Fingerprint-Based Blood Group Detection System" }] }),
  component: () => (
    <ComingSoon
      title="Admin panel"
      description="User management, dataset management, prediction history, activity logs and exports."
    />
  ),
});
