import { createFileRoute, Link } from "@tanstack/react-router";
import { Fingerprint, ShieldCheck, Brain, Activity, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/Logo";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Fingerprint-Based Blood Group Detection System" },
      {
        name: "description",
        content:
          "Predict ABO/Rh blood groups from a fingerprint using BloodScan AI — a hybrid KNN + MDSVM model with 95.53% accuracy.",
      },
    ],
  }),
  component: Landing,
});

const features = [
  {
    icon: Fingerprint,
    title: "Biometric pattern analysis",
    body: "Loops, whorls, and arches are extracted from your fingerprint and fed into a hybrid KNN + MDSVM model.",
  },
  {
    icon: Brain,
    title: "Hybrid ML pipeline",
    body: "KNN handles local similarity; MDSVM optimizes class margins across all 8 ABO/Rh groups.",
  },
  {
    icon: Activity,
    title: "95.53% validation accuracy",
    body: "Trained, tested and validated on thousands of real fingerprint samples across blood groups.",
  },
  {
    icon: ShieldCheck,
    title: "Private & secure",
    body: "Your scans are encrypted, scoped to your account, and never shared. HIPAA-aware design.",
  },
];

const groups = ["A+", "A−", "B+", "B−", "AB+", "AB−", "O+", "O−"];

function Landing() {
  return (
    <div className="min-h-screen bg-hero text-foreground">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
        <Link to="/"><Logo /></Link>
        <nav className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <Link to="/about" className="hover:text-foreground">About</Link>
          <Link to="/research" className="hover:text-foreground">Research</Link>
          <Link to="/dataset" className="hover:text-foreground">Dataset</Link>
          <Link to="/contact" className="hover:text-foreground">Contact</Link>
        </nav>
        <div className="flex items-center gap-2">
          <Link to="/auth">
            <Button variant="ghost" size="sm">Sign in</Button>
          </Link>
          <Link to="/prediction">
            <Button size="sm" className="bg-primary hover:bg-primary/90">Sign up</Button>
          </Link>
        </div>
      </header>

      <section className="relative mx-auto max-w-7xl px-6 pb-24 pt-16 md:pt-24">
        <div className="grid items-center gap-12 md:grid-cols-2">
          <div>
            <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1 text-xs text-muted-foreground backdrop-blur">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-primary" />
              AI healthcare · KNN + MDSVM · 95.53% accuracy
            </div>
            <h1 className="mt-6 text-5xl font-bold leading-[1.05] tracking-tight md:text-6xl">
              Your blood group, <span className="text-gradient">hidden in your fingertip.</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg text-muted-foreground">
              BloodScan AI predicts ABO and Rh blood groups directly from a fingerprint —
              no needles, no labs. Powered by a hybrid machine learning pipeline trained on
              thousands of real samples.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/prediction">
                <Button size="lg" className="bg-primary text-primary-foreground shadow-glow hover:bg-primary/90">
                  Scan a fingerprint
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <a href="#science">
                <Button size="lg" variant="outline" className="border-border bg-card/40 backdrop-blur">
                  How the model works
                </Button>
              </a>
            </div>
            <dl className="mt-10 grid max-w-md grid-cols-3 gap-6 text-sm">
              <div>
                <dt className="text-muted-foreground">Accuracy</dt>
                <dd className="mt-1 font-display text-2xl">95.53%</dd>
              </div>
              <div>
                <dt className="text-muted-foreground">Classes</dt>
                <dd className="mt-1 font-display text-2xl">8 ABO/Rh</dd>
              </div>
              <div>
                <dt className="text-muted-foreground">Models</dt>
                <dd className="mt-1 font-display text-2xl">KNN+MDSVM</dd>
              </div>
            </dl>
          </div>

          <div className="relative">
            <div className="absolute -inset-10 -z-10 rounded-full bg-primary/20 blur-3xl" />
            <div className="rounded-3xl border border-border bg-card/70 p-8 backdrop-blur shadow-card-elegant">
              <div className="flex items-center justify-between text-xs text-muted-foreground">
                <span>Live prediction preview</span>
                <span className="rounded bg-accent/20 px-2 py-0.5 text-accent">demo</span>
              </div>
              <div className="mt-6 grid place-items-center">
                <div className="relative grid h-56 w-56 place-items-center rounded-full bg-gradient-to-br from-primary/30 to-accent/20 ring-1 ring-border">
                  <Fingerprint className="h-32 w-32 text-primary/80" strokeWidth={1.2} />
                  <div className="absolute inset-0 animate-pulse rounded-full ring-2 ring-primary/40" />
                </div>
              </div>
              <div className="mt-6 grid grid-cols-2 gap-3 text-sm">
                <div className="rounded-lg border border-border bg-background/40 p-3">
                  <div className="text-muted-foreground text-xs">Predicted group</div>
                  <div className="mt-1 font-display text-2xl text-primary">O+</div>
                </div>
                <div className="rounded-lg border border-border bg-background/40 p-3">
                  <div className="text-muted-foreground text-xs">Confidence</div>
                  <div className="mt-1 font-display text-2xl">96.2%</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="science" className="mx-auto max-w-7xl px-6 py-20">
        <h2 className="max-w-2xl text-3xl font-semibold md:text-4xl">
          Built on real biometrics. Trained on real data.
        </h2>
        <p className="mt-4 max-w-2xl text-muted-foreground">
          Ridge patterns correlate with ABO antigens. Our pipeline fuses K-Nearest Neighbours
          with a Multi-class Decision Support Vector Machine to push accuracy past traditional
          single-model classifiers.
        </p>
        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => (
            <div
              key={f.title}
              className="group rounded-2xl border border-border bg-card/60 p-6 backdrop-blur transition hover:border-primary/50"
            >
              <div className="grid h-10 w-10 place-items-center rounded-lg bg-primary/15 text-primary ring-1 ring-primary/30">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 font-display text-lg">{f.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{f.body}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="how" className="mx-auto max-w-7xl px-6 py-20">
        <div className="grid gap-12 md:grid-cols-3">
          {[
            { n: "01", t: "Upload fingerprint", d: "Drop a BMP/PNG/JPG fingerprint scan into the prediction console." },
            { n: "02", t: "Hybrid ML inference", d: "Image features run through KNN similarity + MDSVM margin classifier." },
            { n: "03", t: "Get your report", d: "Blood group, confidence score and a downloadable PDF report — instantly." },
          ].map((s) => (
            <div key={s.n} className="rounded-2xl border border-border bg-card/50 p-6">
              <div className="font-mono text-sm text-primary">{s.n}</div>
              <div className="mt-2 font-display text-xl">{s.t}</div>
              <p className="mt-2 text-sm text-muted-foreground">{s.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="groups" className="mx-auto max-w-7xl px-6 py-20">
        <h2 className="text-3xl font-semibold md:text-4xl">Eight blood groups, one fingertip.</h2>
        <div className="mt-10 grid grid-cols-4 gap-3 md:grid-cols-8">
          {groups.map((g) => (
            <div
              key={g}
              className="grid aspect-square place-items-center rounded-xl border border-border bg-card/60 font-display text-2xl transition hover:border-primary/60 hover:bg-primary/10"
            >
              {g}
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-6 pb-24">
        <div className="rounded-3xl border border-primary/30 bg-gradient-to-br from-primary/15 to-accent/10 p-10 text-center shadow-glow">
          <h2 className="font-display text-3xl md:text-4xl">Ready to scan your first fingerprint?</h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Create a free account and run an instant blood group prediction.
          </p>
          <Link to="/prediction" className="mt-6 inline-block">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90">
              Get started free
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>
      </section>

      <footer className="border-t border-border/60 py-8 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Fingerprint-Based Blood Group Detection System · Powered by BloodScan AI · For research and educational use only — not a substitute for clinical blood typing.
      </footer>
    </div>
  );
}
