import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { Database, Droplets, GitBranch, Sparkles, AlertTriangle, ArrowLeft } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { getDatasetStats } from "@/lib/dataset.functions";
import { Logo } from "@/components/Logo";

const datasetQuery = queryOptions({
  queryKey: ["dataset-stats"],
  queryFn: () => getDatasetStats(),
});

export const Route = createFileRoute("/dataset")({
  head: () => ({
    meta: [
      { title: "Dataset Dashboard — Fingerprint-Based Blood Group Detection System" },
      { name: "description", content: "Fingerprint dataset breakdown: totals, splits, class distribution and data quality score." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(datasetQuery),
  component: DatasetPage,
  errorComponent: ({ error }) => (
    <div className="p-8 text-sm text-destructive">Failed to load dataset stats: {error.message}</div>
  ),
});

const CLASS_COLORS: Record<string, string> = {
  "A+": "#ef4444",
  "A-": "#f97316",
  "B+": "#eab308",
  "B-": "#84cc16",
  "AB+": "#06b6d4",
  "AB-": "#3b82f6",
  "O+": "#a855f7",
  "O-": "#ec4899",
};

function DatasetPage() {
  const { data } = useSuspenseQuery(datasetQuery);

  const chartData = data.classes.map((c) => ({
    name: c.blood_group,
    count: c.count,
    fill: CLASS_COLORS[c.blood_group],
  }));

  const splitData = [
    { name: "Train (70%)", value: data.splits.train, fill: "#3b82f6" },
    { name: "Validation (15%)", value: data.splits.validation, fill: "#a855f7" },
    { name: "Test (15%)", value: data.splits.test, fill: "#ec4899" },
  ];

  return (
    <div className="min-h-screen bg-hero text-foreground">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-6 py-6">
        <Link to="/"><Logo /></Link>
        <Link to="/" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back
        </Link>
      </header>

      <main className="mx-auto max-w-7xl px-6 pb-20">
        <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-display text-4xl font-bold tracking-tight">Dataset Dashboard</h1>
            <p className="mt-2 text-sm text-muted-foreground">
              Live overview of the fingerprint corpus powering the model.
            </p>
          </div>
          <Badge variant={data.source === "database" ? "default" : "secondary"} className="gap-1.5">
            <Database className="h-3 w-3" />
            {data.source === "database" ? "Live from Cloud Storage" : "Drive baseline (mirror pending)"}
          </Badge>
        </div>

        {/* Summary tiles */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatTile label="Total images" value={data.total.toLocaleString()} icon={Database} />
          <StatTile label="Classes covered" value={`${8 - data.quality.missingClasses.length} / 8`} icon={Droplets} />
          <StatTile label="Train / Val / Test" value={`${data.splits.train} / ${data.splits.validation} / ${data.splits.test}`} icon={GitBranch} />
          <StatTile label="Quality score" value={`${data.quality.score} / 100`} icon={Sparkles} accent />
        </div>

        {/* Charts */}
        <div className="mt-8 grid gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="text-base">Class distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                    <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <Tooltip
                      contentStyle={{
                        background: "hsl(var(--background))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                      {chartData.map((d) => (
                        <Cell key={d.name} fill={d.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Train / Validation / Test</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie data={splitData} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90} paddingAngle={2}>
                      {splitData.map((d) => (
                        <Cell key={d.name} fill={d.fill} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        background: "hsl(var(--background))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-2 space-y-1.5 text-xs">
                {splitData.map((s) => (
                  <div key={s.name} className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <span className="h-2.5 w-2.5 rounded-sm" style={{ background: s.fill }} />
                      {s.name}
                    </span>
                    <span className="font-mono tabular-nums">{s.value.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quality breakdown */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="text-base">Data quality breakdown</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-6 md:grid-cols-3">
            <QualityMeter label="Class balance" value={data.quality.classBalance} hint="Evenness across present classes" />
            <QualityMeter label="Class coverage" value={data.quality.coverage} hint="Share of 8 ABO/Rh groups present" />
            <QualityMeter label="Volume" value={data.quality.volume} hint="Saturates near 8,000 samples" />

            {data.quality.missingClasses.length > 0 && (
              <div className="md:col-span-3 flex items-start gap-3 rounded-lg border border-amber-500/30 bg-amber-500/5 p-4 text-sm">
                <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
                <div>
                  <div className="font-medium text-foreground">Missing training data</div>
                  <div className="mt-1 text-muted-foreground">
                    No samples yet for:{" "}
                    {data.quality.missingClasses.map((g, i) => (
                      <span key={g} className="font-mono text-foreground">
                        {g}
                        {i < data.quality.missingClasses.length - 1 ? ", " : ""}
                      </span>
                    ))}
                    . The model can't predict these classes until images are added.
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Per-class table */}
        <Card className="mt-6">
          <CardHeader>
            <CardTitle className="text-base">Per-class breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-hidden rounded-lg border border-border">
              <table className="w-full text-sm">
                <thead className="bg-muted/30 text-xs uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="px-4 py-2 text-left">Blood group</th>
                    <th className="px-4 py-2 text-right">Total</th>
                    <th className="px-4 py-2 text-right">Train</th>
                    <th className="px-4 py-2 text-right">Val</th>
                    <th className="px-4 py-2 text-right">Test</th>
                    <th className="px-4 py-2 text-right">% of dataset</th>
                  </tr>
                </thead>
                <tbody>
                  {data.classes.map((c) => {
                    const train = Math.round(c.count * 0.7);
                    const val = Math.round(c.count * 0.15);
                    const test = c.count - train - val;
                    const pct = data.total > 0 ? (c.count / data.total) * 100 : 0;
                    return (
                      <tr key={c.blood_group} className="border-t border-border">
                        <td className="px-4 py-2 font-mono font-medium">
                          <span className="inline-flex items-center gap-2">
                            <span className="h-2.5 w-2.5 rounded-sm" style={{ background: CLASS_COLORS[c.blood_group] }} />
                            {c.blood_group}
                          </span>
                        </td>
                        <td className="px-4 py-2 text-right tabular-nums">{c.count.toLocaleString()}</td>
                        <td className="px-4 py-2 text-right tabular-nums text-muted-foreground">{train}</td>
                        <td className="px-4 py-2 text-right tabular-nums text-muted-foreground">{val}</td>
                        <td className="px-4 py-2 text-right tabular-nums text-muted-foreground">{test}</td>
                        <td className="px-4 py-2 text-right tabular-nums">{pct.toFixed(1)}%</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}

function StatTile({
  label,
  value,
  icon: Icon,
  accent,
}: {
  label: string;
  value: string;
  icon: React.ComponentType<{ className?: string }>;
  accent?: boolean;
}) {
  return (
    <Card className={accent ? "border-primary/40 bg-primary/5" : ""}>
      <CardContent className="flex items-start justify-between p-5">
        <div>
          <p className="text-xs uppercase tracking-wide text-muted-foreground">{label}</p>
          <p className="mt-2 font-display text-2xl font-semibold">{value}</p>
        </div>
        <Icon className={`h-5 w-5 ${accent ? "text-primary" : "text-muted-foreground"}`} />
      </CardContent>
    </Card>
  );
}

function QualityMeter({ label, value, hint }: { label: string; value: number; hint: string }) {
  return (
    <div>
      <div className="flex items-baseline justify-between">
        <span className="text-sm font-medium">{label}</span>
        <span className="font-mono text-sm tabular-nums">{value}%</span>
      </div>
      <Progress value={value} className="mt-2" />
      <p className="mt-1.5 text-xs text-muted-foreground">{hint}</p>
    </div>
  );
}
