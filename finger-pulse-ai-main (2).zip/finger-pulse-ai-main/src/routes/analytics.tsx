import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/ComingSoon";

export const Route = createFileRoute("/analytics")({
  head: () => ({ meta: [{ title: "Analytics — Fingerprint-Based Blood Group Detection System" }] }),
  component: () => (
    <ComingSoon
      title="Prediction analytics"
      description="Confidence trends, class distribution, model accuracy and usage metrics."
    />
  ),
});
