import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/ComingSoon";

export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — Fingerprint-Based Blood Group Detection System" }] }),
  component: () => (
    <ComingSoon
      title="Your dashboard"
      description="Your scan history, recent predictions and downloadable reports will live here."
    />
  ),
});
