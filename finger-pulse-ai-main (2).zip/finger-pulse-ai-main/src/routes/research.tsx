import { createFileRoute, Link } from "@tanstack/react-router";
import { Logo } from "@/components/Logo";

export const Route = createFileRoute("/research")({
  head: () => ({
    meta: [
      { title: "Research — Fingerprint-Based Blood Group Detection System" },
      { name: "description", content: "The science behind BloodScan AI's fingerprint blood group prediction." },
    ],
  }),
  component: ResearchPage,
});

function ResearchPage() {
  return (
    <div className="min-h-screen bg-hero text-foreground">
      <header className="mx-auto flex max-w-5xl items-center justify-between px-6 py-6">
        <Link to="/"><Logo /></Link>
        <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">← Home</Link>
      </header>
      <main className="mx-auto max-w-3xl px-6 py-12">
        <h1 className="font-display text-4xl">The science</h1>
        <p className="mt-4 text-muted-foreground">
          Fingerprint ridge patterns — loops, whorls, arches — have shown statistical correlation
          with ABO blood group antigens in multiple peer-reviewed studies. BloodScan AI combines
          two complementary classifiers to exploit this correlation:
        </p>
        <div className="mt-8 grid gap-4 md:grid-cols-2">
          <div className="rounded-2xl border border-border bg-card/60 p-6">
            <h2 className="font-display text-xl">K-Nearest Neighbours</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Captures local ridge-pattern similarity against thousands of labelled samples.
            </p>
          </div>
          <div className="rounded-2xl border border-border bg-card/60 p-6">
            <h2 className="font-display text-xl">MDSVM</h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Multi-class Decision SVM optimizes class margins across all 8 ABO/Rh groups.
            </p>
          </div>
        </div>
        <h2 className="mt-12 font-display text-2xl">Validation</h2>
        <p className="mt-3 text-muted-foreground">
          The current ensemble achieves <strong>95.53%</strong> validation accuracy on a held-out
          test set, with stratified 70/15/15 train/validation/test splits.
        </p>
      </main>
    </div>
  );
}
