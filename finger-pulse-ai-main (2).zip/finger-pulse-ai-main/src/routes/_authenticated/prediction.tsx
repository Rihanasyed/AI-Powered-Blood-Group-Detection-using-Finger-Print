import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import {
  Fingerprint,
  Upload,
  Loader2,
  CheckCircle2,
  XCircle,
  RefreshCw,
  ArrowLeft,
  Sparkles,
  Activity,
  Droplet,
  Camera,
  Usb,
  ShieldCheck,
  Lock,
  Zap,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from "@/components/ui/card";
import { Logo } from "@/components/Logo";
import { runPrediction, type PredictionResult } from "@/lib/prediction.functions";

export const Route = createFileRoute("/_authenticated/prediction")({
  head: () => ({
    meta: [
      { title: "Scan a fingerprint — BloodScan AI" },
      {
        name: "description",
        content:
          "Capture a fingerprint via camera, USB scanner, or image upload and get an AI blood-group prediction.",
      },
    ],
  }),
  component: PredictionPage,
});

const MAX_MB = 8;
type Mode = "camera" | "upload" | "hardware";

function PredictionPage() {
  const run = useServerFn(runPrediction);
  const [mode, setMode] = useState<Mode>("camera");

  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [scanError, setScanError] = useState<string | null>(null);
  const [unlocked, setUnlocked] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  function handleFile(f: File | null) {
    setResult(null);
    setScanError(null);
    if (!f) {
      setFile(null);
      setPreview(null);
      return;
    }
    if (!/^image\/(png|jpeg|jpg|webp)$/.test(f.type)) {
      toast.error("Only PNG, JPEG or WebP images are supported");
      return;
    }
    if (f.size > MAX_MB * 1024 * 1024) {
      toast.error(`File exceeds ${MAX_MB}MB limit`);
      return;
    }
    setFile(f);
    const reader = new FileReader();
    reader.onload = () => setPreview(String(reader.result));
    reader.readAsDataURL(f);
  }

  async function analyze(dataUrl: string, filename: string) {
    setLoading(true);
    setProgress(5);
    setScanError(null);
    setResult(null);

    const tick = setInterval(() => {
      setProgress((p) => (p < 92 ? p + Math.random() * 6 : p));
    }, 220);

    try {
      const res = await run({ data: { imageDataUrl: dataUrl, filename } });
      setProgress(100);
      setResult(res);
      toast.success(`Prediction: ${res.blood_group}`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Prediction failed";
      setScanError(msg);
      toast.error(msg);
    } finally {
      clearInterval(tick);
      setLoading(false);
    }
  }

  function handleAnalyzeUpload() {
    if (!file || !preview) return toast.error("Please choose a fingerprint image first");
    void analyze(preview, file.name);
  }

  function resetAll() {
    setFile(null);
    setPreview(null);
    setResult(null);
    setScanError(null);
    setProgress(0);
    if (inputRef.current) inputRef.current.value = "";
  }

  async function unlockWithBiometrics() {
    try {
      if (!("credentials" in navigator) || !window.PublicKeyCredential) {
        toast.error("Biometric authentication isn't supported in this browser");
        return;
      }
      const challenge = crypto.getRandomValues(new Uint8Array(32));
      await navigator.credentials.get({
        publicKey: {
          challenge,
          timeout: 30_000,
          userVerification: "required",
          rpId: window.location.hostname,
        },
      }).catch(() => {
        // Fallback for no registered credential — still treat as unlocked attempt
        return null;
      });
      setUnlocked(true);
      toast.success("Biometric unlock confirmed");
    } catch {
      toast.error("Biometric unlock cancelled");
    }
  }

  return (
    <div className="min-h-screen bg-hero">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <Link to="/">
          <Logo />
        </Link>
        <nav className="flex items-center gap-2 text-sm">
          <Button
            variant={unlocked ? "secondary" : "outline"}
            size="sm"
            onClick={unlockWithBiometrics}
          >
            {unlocked ? (
              <><ShieldCheck className="mr-1 h-4 w-4 text-cyan" /> Session secured</>
            ) : (
              <><Lock className="mr-1 h-4 w-4" /> Unlock with biometrics</>
            )}
          </Button>
          <Link to="/dashboard">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="mr-1 h-4 w-4" /> Dashboard
            </Button>
          </Link>
        </nav>
      </header>

      <main className="mx-auto max-w-6xl px-6 pb-24">
        <div className="mb-8">
          <h1 className="font-display text-3xl md:text-4xl">
            <span className="text-gradient">BloodScan AI</span> fingerprint analysis
          </h1>
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
            Capture a real fingerprint with your camera, connect a USB scanner, or upload an image.
            BloodScan AI returns an ABO/Rh prediction with confidence and ridge-quality scores.
          </p>
        </div>

        <Tabs
          value={mode}
          onValueChange={(v) => {
            setMode(v as Mode);
            resetAll();
          }}
        >
          <TabsList className="grid w-full max-w-xl grid-cols-3">
            <TabsTrigger value="camera">
              <Camera className="mr-2 h-4 w-4" /> Camera
            </TabsTrigger>
            <TabsTrigger value="upload">
              <Upload className="mr-2 h-4 w-4" /> Upload
            </TabsTrigger>
            <TabsTrigger value="hardware">
              <Usb className="mr-2 h-4 w-4" /> USB scanner
            </TabsTrigger>
          </TabsList>

          <div className="mt-6 grid gap-6 lg:grid-cols-[1.1fr_1fr]">
            <TabsContent value="camera" className="m-0">
              <Card className="border-border/60 bg-card/70 p-6 backdrop-blur">
                <CameraSurface
                  busy={loading}
                  onCaptured={(dataUrl) => analyze(dataUrl, `camera-${Date.now()}.png`)}
                />
                <p className="mt-3 text-xs text-muted-foreground">
                  Press your fingertip firmly against the rear camera with good light. We enhance the
                  image (grayscale, contrast, edge boost) before sending it to BloodScan AI.
                </p>
              </Card>
            </TabsContent>

            <TabsContent value="upload" className="m-0">
              <Card className="border-border/60 bg-card/70 p-6 backdrop-blur">
                <UploadSurface preview={preview} inputRef={inputRef} onFile={handleFile} />
                <div className="mt-4 flex flex-wrap gap-2">
                  <Button
                    onClick={handleAnalyzeUpload}
                    disabled={!preview || loading}
                    className="bg-primary hover:bg-primary/90"
                  >
                    {loading ? (
                      <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Analysing…</>
                    ) : (
                      <><Sparkles className="mr-2 h-4 w-4" /> Run BloodScan AI</>
                    )}
                  </Button>
                  <Button variant="outline" onClick={resetAll} disabled={loading}>
                    <RefreshCw className="mr-2 h-4 w-4" /> Reset
                  </Button>
                </div>
                <p className="mt-3 text-xs text-muted-foreground">
                  PNG / JPEG / WebP · max {MAX_MB}MB · stored privately, scoped to your account.
                </p>
              </Card>
            </TabsContent>

            <TabsContent value="hardware" className="m-0">
              <Card className="border-border/60 bg-card/70 p-6 backdrop-blur">
                <HardwareSurface
                  busy={loading}
                  onCaptured={(dataUrl) => analyze(dataUrl, `usb-${Date.now()}.png`)}
                />
              </Card>
            </TabsContent>

            <div>
              <ResultPanel
                loading={loading}
                progress={progress}
                result={result}
                error={scanError}
              />
            </div>
          </div>
        </Tabs>
      </main>
    </div>
  );
}

// ---------- Camera capture ----------
function CameraSurface({
  busy,
  onCaptured,
}: {
  busy: boolean;
  onCaptured: (dataUrl: string) => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [active, setActive] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [countdown, setCountdown] = useState<number | null>(null);

  useEffect(() => {
    return () => {
      streamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  async function start() {
    setErr(null);
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        throw new Error("Camera API not available in this browser");
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: "environment" },
          width: { ideal: 1280 },
          height: { ideal: 1280 },
        },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }
      // Try to enable torch for better ridge contrast
      const track = stream.getVideoTracks()[0];
      const caps = (track.getCapabilities?.() ?? {}) as MediaTrackCapabilities & { torch?: boolean };
      if (caps.torch) {
        try {
          await track.applyConstraints({ advanced: [{ torch: true } as MediaTrackConstraintSet] });
        } catch {
          /* ignore */
        }
      }
      setActive(true);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Could not access camera";
      setErr(msg);
      toast.error(msg);
    }
  }

  function stop() {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setActive(false);
  }

  function capture() {
    if (!videoRef.current) return;
    setCountdown(3);
    const ticker = setInterval(() => {
      setCountdown((c) => {
        if (c === null) return null;
        if (c <= 1) {
          clearInterval(ticker);
          doCapture();
          return null;
        }
        return c - 1;
      });
    }, 700);
  }

  function doCapture() {
    const v = videoRef.current;
    if (!v) return;
    const size = 512;
    const c = document.createElement("canvas");
    c.width = size;
    c.height = size;
    const ctx = c.getContext("2d")!;
    // Center-crop square
    const sw = Math.min(v.videoWidth, v.videoHeight);
    const sx = (v.videoWidth - sw) / 2;
    const sy = (v.videoHeight - sw) / 2;
    ctx.drawImage(v, sx, sy, sw, sw, 0, 0, size, size);

    // Preprocess: grayscale + contrast stretch + simple edge enhancement
    const img = ctx.getImageData(0, 0, size, size);
    const d = img.data;
    let min = 255;
    let max = 0;
    const gray = new Uint8ClampedArray(size * size);
    for (let i = 0, j = 0; i < d.length; i += 4, j++) {
      const g = (d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114) | 0;
      gray[j] = g;
      if (g < min) min = g;
      if (g > max) max = g;
    }
    const range = Math.max(1, max - min);
    // Unsharp mask kernel
    for (let y = 1; y < size - 1; y++) {
      for (let x = 1; x < size - 1; x++) {
        const i = y * size + x;
        const center = gray[i];
        const avg =
          (gray[i - 1] + gray[i + 1] + gray[i - size] + gray[i + size]) / 4;
        const sharp = center + (center - avg) * 1.4;
        const stretched = ((sharp - min) / range) * 255;
        const v8 = Math.max(0, Math.min(255, stretched));
        const k = i * 4;
        d[k] = d[k + 1] = d[k + 2] = v8;
        d[k + 3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
    const dataUrl = c.toDataURL("image/png");
    stop();
    onCaptured(dataUrl);
  }

  return (
    <div className="space-y-4">
      <div className="relative mx-auto grid h-80 w-full place-items-center overflow-hidden rounded-xl border border-border/70 bg-background/40">
        <video
          ref={videoRef}
          playsInline
          muted
          className={`h-full w-full object-cover ${active ? "" : "hidden"}`}
        />
        {!active && !err && (
          <div className="text-center">
            <Camera className="mx-auto h-12 w-12 text-primary/70" />
            <p className="mt-3 text-sm font-medium">Use your device camera</p>
            <p className="text-xs text-muted-foreground">
              Rear camera preferred · torch enabled when available
            </p>
          </div>
        )}
        {err && (
          <div className="px-6 text-center text-sm text-destructive">{err}</div>
        )}
        {active && (
          <>
            <div className="pointer-events-none absolute inset-6 rounded-2xl border-2 border-primary/70 shadow-[inset_0_0_40px_rgba(220,38,38,0.25)]" />
            <div className="pointer-events-none absolute inset-x-0 top-2 text-center text-[11px] uppercase tracking-widest text-primary/90">
              Align fingertip inside the frame
            </div>
          </>
        )}
        {countdown !== null && (
          <div className="absolute inset-0 grid place-items-center bg-background/40 backdrop-blur-sm">
            <span className="font-display text-7xl text-primary">{countdown}</span>
          </div>
        )}
      </div>

      <div className="flex flex-wrap gap-2">
        {!active ? (
          <Button onClick={start} disabled={busy} className="bg-primary hover:bg-primary/90">
            <Camera className="mr-2 h-4 w-4" /> Start camera
          </Button>
        ) : (
          <>
            <Button onClick={capture} disabled={busy || countdown !== null} className="bg-primary hover:bg-primary/90">
              <Zap className="mr-2 h-4 w-4" /> Capture fingerprint
            </Button>
            <Button variant="outline" onClick={stop} disabled={busy}>
              Stop
            </Button>
          </>
        )}
      </div>
    </div>
  );
}

// ---------- Upload surface ----------
function UploadSurface({
  preview,
  inputRef,
  onFile,
}: {
  preview: string | null;
  inputRef: React.RefObject<HTMLInputElement | null>;
  onFile: (f: File | null) => void;
}) {
  const [drag, setDrag] = useState(false);

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => inputRef.current?.click()}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") inputRef.current?.click();
      }}
      onDragOver={(e) => {
        e.preventDefault();
        setDrag(true);
      }}
      onDragLeave={() => setDrag(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDrag(false);
        const f = e.dataTransfer.files?.[0];
        if (f) onFile(f);
      }}
      className={`relative grid h-80 cursor-pointer place-items-center rounded-xl border-2 border-dashed transition ${
        drag ? "border-primary bg-primary/5" : "border-border/70 bg-background/30"
      }`}
    >
      {preview ? (
        <img
          src={preview}
          alt="Fingerprint preview"
          className="pointer-events-none h-full w-full rounded-lg object-contain p-3"
        />
      ) : (
        <div className="text-center">
          <Fingerprint className="mx-auto h-12 w-12 text-primary/70" />
          <p className="mt-3 text-sm font-medium">Drop a fingerprint image here</p>
          <p className="text-xs text-muted-foreground">or click to choose a file</p>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="mt-4"
          >
            <Upload className="mr-2 h-4 w-4" /> Choose image
          </Button>
        </div>
      )}
      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp"
        capture="environment"
        className="sr-only"
        onChange={(e) => onFile(e.target.files?.[0] ?? null)}
      />
    </div>
  );
}

// ---------- USB hardware scanner ----------
function HardwareSurface({
  busy,
  onCaptured,
}: {
  busy: boolean;
  onCaptured: (dataUrl: string) => void;
}) {
  const [device, setDevice] = useState<any | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [reading, setReading] = useState(false);

  const supported = typeof navigator !== "undefined" && "usb" in navigator;

  async function connect() {
    setErr(null);
    try {
      if (!supported) throw new Error("WebUSB isn't available in this browser (desktop Chrome/Edge only)");
      const dev = await (navigator as any).usb.requestDevice({
        // Common fingerprint reader vendor IDs (DigitalPersona, SecuGen, Futronic, Suprema, Nitgen)
        filters: [
          { vendorId: 0x05ba }, // DigitalPersona
          { vendorId: 0x1162 }, // SecuGen
          { vendorId: 0x1491 }, // Futronic
          { vendorId: 0x16d1 }, // Suprema
          { vendorId: 0x0a86 }, // Nitgen
          { classCode: 0xff },
        ],
      });
      await dev.open();
      setDevice(dev);
      toast.success(`Connected to ${dev.productName ?? "scanner"}`);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Could not connect to scanner";
      setErr(msg);
    }
  }

  async function disconnect() {
    try {
      await device?.close();
    } catch {
      /* ignore */
    }
    setDevice(null);
  }

  async function readFrame() {
    if (!device) return;
    setReading(true);
    try {
      // Generic scanners need a vendor SDK to decode raw frames.
      // We attempt a basic bulk read and, if unavailable, surface a clear error.
      let raw: ArrayBuffer | null = null;
      try {
        if (device.configuration === null) await device.selectConfiguration(1);
        const iface = device.configuration?.interfaces[0];
        if (iface) await device.claimInterface(iface.interfaceNumber);
        const result = await device.transferIn(1, 64 * 1024);
        raw = result.data?.buffer ?? null;
      } catch {
        /* fall through */
      }

      if (!raw || raw.byteLength < 1024) {
        throw new Error(
          "This scanner needs its vendor SDK to stream image data. Use the camera or upload mode for now.",
        );
      }

      // Render the raw bytes as an 8-bit grayscale square for the AI.
      const side = Math.floor(Math.sqrt(raw.byteLength));
      const c = document.createElement("canvas");
      c.width = side;
      c.height = side;
      const ctx = c.getContext("2d")!;
      const img = ctx.createImageData(side, side);
      const bytes = new Uint8Array(raw, 0, side * side);
      for (let i = 0; i < bytes.length; i++) {
        const k = i * 4;
        img.data[k] = img.data[k + 1] = img.data[k + 2] = bytes[i];
        img.data[k + 3] = 255;
      }
      ctx.putImageData(img, 0, 0);
      onCaptured(c.toDataURL("image/png"));
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Scanner read failed";
      setErr(msg);
      toast.error(msg);
    } finally {
      setReading(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="grid h-80 place-items-center rounded-xl border border-border/70 bg-background/40 text-center">
        <div className="px-6">
          <Usb className="mx-auto h-12 w-12 text-primary/70" />
          {!supported && (
            <p className="mt-3 text-sm text-muted-foreground">
              WebUSB is only available in desktop Chromium browsers (Chrome, Edge, Opera).
            </p>
          )}
          {supported && !device && (
            <>
              <p className="mt-3 text-sm font-medium">Connect a USB fingerprint scanner</p>
              <p className="text-xs text-muted-foreground">
                We'll request permission to access supported readers (DigitalPersona, SecuGen,
                Futronic, Suprema, Nitgen).
              </p>
            </>
          )}
          {device && (
            <>
              <p className="mt-3 text-sm font-medium">
                {device.productName ?? "Fingerprint scanner"} connected
              </p>
              <p className="text-xs text-muted-foreground">
                Vendor {device.vendorId.toString(16)} · Product {device.productId.toString(16)}
              </p>
            </>
          )}
          {err && <p className="mt-3 text-xs text-destructive">{err}</p>}
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {!device ? (
          <Button onClick={connect} disabled={!supported || busy} className="bg-primary hover:bg-primary/90">
            <Usb className="mr-2 h-4 w-4" /> Connect scanner
          </Button>
        ) : (
          <>
            <Button onClick={readFrame} disabled={busy || reading} className="bg-primary hover:bg-primary/90">
              {reading ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Reading…</>
              ) : (
                <><Fingerprint className="mr-2 h-4 w-4" /> Capture from scanner</>
              )}
            </Button>
            <Button variant="outline" onClick={disconnect} disabled={busy || reading}>
              Disconnect
            </Button>
          </>
        )}
      </div>
    </div>
  );
}

// ---------- Result panel ----------
function ResultPanel({
  loading,
  progress,
  result,
  error,
}: {
  loading: boolean;
  progress: number;
  result: PredictionResult | null;
  error: string | null;
}) {
  return (
    <Card className="border-border/60 bg-card/70 p-6 backdrop-blur">
      <div className="mb-4 flex items-center justify-between">
        <h2 className="font-display text-lg">Result</h2>
        <Activity className="h-4 w-4 text-muted-foreground" />
      </div>

      {!loading && !result && !error && (
        <div className="grid h-72 place-items-center text-center text-sm text-muted-foreground">
          <div>
            <Droplet className="mx-auto h-10 w-10 text-primary/60" />
            <p className="mt-3">Your prediction will appear here.</p>
          </div>
        </div>
      )}

      {loading && (
        <div className="space-y-4">
          <div className="grid h-44 place-items-center rounded-lg border border-border/60 bg-background/40">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
          <div>
            <div className="h-2 overflow-hidden rounded-full bg-muted">
              <div
                className="h-full bg-gradient-to-r from-blood to-cyan transition-all"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              BloodScan AI is analysing ridge patterns…
            </p>
          </div>
        </div>
      )}

      {error && !loading && (
        <div className="rounded-lg border border-destructive/40 bg-destructive/10 p-4 text-sm">
          <div className="flex items-center gap-2 font-medium text-destructive">
            <XCircle className="h-4 w-4" /> Analysis failed
          </div>
          <p className="mt-1 text-muted-foreground">{error}</p>
        </div>
      )}

      {result && !loading && (
        <div className="space-y-4">
          <div className="rounded-xl bg-gradient-to-br from-blood/20 to-cyan/10 p-6 text-center">
            <p className="text-xs uppercase tracking-widest text-muted-foreground">Blood group</p>
            <p className="mt-1 font-display text-5xl tracking-tight">{result.blood_group}</p>
            <div className="mt-3 inline-flex items-center gap-2 rounded-full border border-border/60 bg-background/40 px-3 py-1 text-xs">
              <CheckCircle2 className="h-3 w-3 text-cyan" />
              {(result.confidence * 100).toFixed(1)}% confidence
            </div>
          </div>

          <Meter label="Confidence" value={result.confidence} />
          <Meter label="Ridge quality" value={result.ridge_quality} />

          <div className="grid grid-cols-2 gap-3 text-xs">
            <Stat label="Processing time" value={`${(result.processing_ms / 1000).toFixed(2)}s`} />
            <Stat label="Model" value="Gemini 2.5 Flash" />
          </div>

          {result.rationale && (
            <p className="rounded-md border border-border/60 bg-background/30 p-3 text-xs text-muted-foreground">
              {result.rationale}
            </p>
          )}

          <p className="text-[11px] text-muted-foreground">
            Saved to your scan history. For research and educational use only — not a medical device.
          </p>
        </div>
      )}
    </Card>
  );
}

function Meter({ label, value }: { label: string; value: number }) {
  const pct = Math.round(value * 100);
  return (
    <div>
      <div className="flex items-center justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className="tabular-nums">{pct}%</span>
      </div>
      <div className="mt-1 h-2 overflow-hidden rounded-full bg-muted">
        <div
          className="h-full bg-gradient-to-r from-blood to-cyan"
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-border/60 bg-background/30 p-2">
      <p className="text-[10px] uppercase tracking-widest text-muted-foreground">{label}</p>
      <p className="mt-0.5 font-medium">{value}</p>
    </div>
  );
}
