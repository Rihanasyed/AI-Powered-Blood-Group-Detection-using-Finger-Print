import { createFileRoute } from "@tanstack/react-router";
import { ComingSoon } from "@/components/ComingSoon";

export const Route = createFileRoute("/profile")({
  head: () => ({ meta: [{ title: "Profile — Fingerprint-Based Blood Group Detection System" }] }),
  component: () => (
    <ComingSoon
      title="Your profile"
      description="Manage your account, full name, avatar and notification preferences."
    />
  ),
});
