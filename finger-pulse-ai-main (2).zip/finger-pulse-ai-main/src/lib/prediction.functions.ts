import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"] as const;
type BloodGroup = (typeof BLOOD_GROUPS)[number];

const inputSchema = z.object({
  // data URL: "data:image/png;base64,...."
  imageDataUrl: z
    .string()
    .min(64, "Image is too small")
    .max(12_000_000, "Image is too large (max ~9MB)"),
  filename: z.string().min(1).max(180),
});

export type PredictionResult = {
  id: string;
  blood_group: BloodGroup;
  confidence: number;
  ridge_quality: number;
  processing_ms: number;
  rationale: string;
  storage_path: string;
  created_at: string;
};

const SYSTEM_PROMPT = `You are BloodScan AI, an experimental ML engine that predicts ABO/Rh blood groups from fingerprint ridge patterns (loops, whorls, arches, minutiae density).
The user uploads a fingerprint image. Analyse it and respond ONLY with strict JSON of the shape:
{"blood_group":"A+|A-|B+|B-|AB+|AB-|O+|O-","confidence":0-1,"ridge_quality":0-1,"rationale":"<=240 chars"}
- confidence is your model confidence
- ridge_quality reflects how clear/usable the ridge pattern is
- If the image is not a fingerprint at all, set blood_group to "O+", confidence to 0.05 and explain in rationale.
Never add markdown, never add prose outside the JSON.`;

export const runPrediction = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => inputSchema.parse(data))
  .handler(async ({ data, context }) => {
    const started = Date.now();
    const { userId } = context;
    const apiKey = process.env.LOVABLE_API_KEY;
    if (!apiKey) throw new Error("LOVABLE_API_KEY is not configured");

    // ---- 1. Decode the data URL ----
    const match = data.imageDataUrl.match(/^data:(image\/(png|jpeg|jpg|webp));base64,(.+)$/);
    if (!match) throw new Error("Unsupported image format. Use PNG, JPEG or WebP.");
    const mime = match[1];
    const ext = match[2] === "jpg" ? "jpeg" : match[2];
    const base64 = match[3];
    const bytes = Buffer.from(base64, "base64");
    if (bytes.byteLength > 8 * 1024 * 1024) {
      throw new Error("Image exceeds the 8MB upload limit.");
    }

    // ---- 2. Call the Lovable AI Gateway (Gemini vision) ----
    const aiRes = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Lovable-API-Key": apiKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          {
            role: "user",
            content: [
              { type: "text", text: "Analyse this fingerprint and return strict JSON only." },
              { type: "image_url", image_url: { url: data.imageDataUrl } },
            ],
          },
        ],
      }),
    });

    if (!aiRes.ok) {
      const body = await aiRes.text().catch(() => "");
      if (aiRes.status === 429) throw new Error("Rate limit reached — try again in a minute.");
      if (aiRes.status === 402)
        throw new Error("AI credits exhausted. Add credits in Settings → Workspace.");
      throw new Error(`AI gateway error (${aiRes.status}): ${body.slice(0, 200)}`);
    }

    const aiJson = (await aiRes.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const raw = aiJson.choices?.[0]?.message?.content ?? "";
    const cleaned = raw.replace(/```json|```/g, "").trim();
    let parsed: { blood_group: string; confidence: number; ridge_quality: number; rationale: string };
    try {
      parsed = JSON.parse(cleaned);
    } catch {
      throw new Error("AI response was not valid JSON. Please retry.");
    }

    const group = (BLOOD_GROUPS as readonly string[]).includes(parsed.blood_group)
      ? (parsed.blood_group as BloodGroup)
      : "O+";
    const confidence = Math.max(0, Math.min(1, Number(parsed.confidence) || 0));
    const ridge_quality = Math.max(0, Math.min(1, Number(parsed.ridge_quality) || 0));
    const rationale = String(parsed.rationale ?? "").slice(0, 240);

    // ---- 3. Persist image + row using the admin client ----
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const safeName = data.filename.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80);
    const storagePath = `${userId}/${Date.now()}-${crypto.randomUUID()}-${safeName}.${ext}`;

    const up = await supabaseAdmin.storage
      .from("fingerprints")
      .upload(storagePath, bytes, { contentType: mime, upsert: false });
    if (up.error) throw new Error(`Storage upload failed: ${up.error.message}`);

    const ins = await supabaseAdmin
      .from("predictions")
      .insert({
        user_id: userId,
        image_path: storagePath,
        predicted_blood_group: group,
        confidence,
        model: "google/gemini-3-flash-preview",
        raw_response: { ...parsed, ridge_quality, rationale },
      })
      .select("id, created_at")
      .single();
    if (ins.error) throw new Error(`Could not save prediction: ${ins.error.message}`);

    return {
      id: ins.data.id,
      blood_group: group,
      confidence,
      ridge_quality,
      processing_ms: Date.now() - started,
      rationale,
      storage_path: storagePath,
      created_at: ins.data.created_at,
    } satisfies PredictionResult;
  });
