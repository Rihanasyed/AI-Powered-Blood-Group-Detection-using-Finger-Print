import { createServerFn } from "@tanstack/react-start";

// Known counts from the Drive scan (used as baseline until the mirror job runs).
const DRIVE_BASELINE: Record<string, number> = {
  "A+": 565,
  "A-": 1011,
  "B+": 652,
  "B-": 0,
  "AB+": 0,
  "AB-": 761,
  "O+": 723,
  "O-": 0,
};

const ALL_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

export type DatasetStats = {
  source: "database" | "drive_baseline";
  total: number;
  classes: { blood_group: string; count: number }[];
  splits: { train: number; validation: number; test: number };
  quality: {
    score: number;
    classBalance: number;
    coverage: number;
    volume: number;
    missingClasses: string[];
  };
};

function computeStats(counts: Record<string, number>, source: DatasetStats["source"]): DatasetStats {
  const classes = ALL_GROUPS.map((g) => ({ blood_group: g, count: counts[g] ?? 0 }));
  const total = classes.reduce((s, c) => s + c.count, 0);

  // 70 / 15 / 15 stratified split
  const train = Math.round(total * 0.7);
  const validation = Math.round(total * 0.15);
  const test = total - train - validation;

  const present = classes.filter((c) => c.count > 0);
  const missingClasses = classes.filter((c) => c.count === 0).map((c) => c.blood_group);

  // Class balance: 1 - normalized std-dev of present classes (0..1)
  let classBalance = 0;
  if (present.length > 1) {
    const mean = present.reduce((s, c) => s + c.count, 0) / present.length;
    const variance =
      present.reduce((s, c) => s + (c.count - mean) ** 2, 0) / present.length;
    const std = Math.sqrt(variance);
    classBalance = Math.max(0, 1 - std / mean);
  } else if (present.length === 1) {
    classBalance = 1;
  }

  const coverage = present.length / ALL_GROUPS.length; // 0..1
  // Volume score: saturates near 8000 images
  const volume = Math.min(1, total / 8000);

  // Weighted quality score (0..100)
  const score = Math.round((classBalance * 0.4 + coverage * 0.4 + volume * 0.2) * 100);

  return {
    source,
    total,
    classes,
    splits: { train, validation, test },
    quality: {
      score,
      classBalance: Math.round(classBalance * 100),
      coverage: Math.round(coverage * 100),
      volume: Math.round(volume * 100),
      missingClasses,
    },
  };
}

export const getDatasetStats = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("dataset_images")
    .select("blood_group");

  if (error) {
    return computeStats(DRIVE_BASELINE, "drive_baseline");
  }

  if (!data || data.length === 0) {
    return computeStats(DRIVE_BASELINE, "drive_baseline");
  }

  const counts: Record<string, number> = {};
  for (const row of data) {
    counts[row.blood_group] = (counts[row.blood_group] ?? 0) + 1;
  }
  return computeStats(counts, "database");
});
