import logoSrc from "@/assets/logo.png";

type Props = {
  size?: number;
  withWordmark?: boolean;
  className?: string;
};

export function Logo({ size = 36, withWordmark = true, className = "" }: Props) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <img
        src={logoSrc}
        alt="BloodScan AI logo"
        width={size}
        height={size}
        className="rounded-md"
      />
      {withWordmark && (
        <span className="font-display text-lg font-semibold tracking-tight leading-tight">
          BloodScan<span className="text-primary">.AI</span>
        </span>
      )}
    </div>
  );
}
