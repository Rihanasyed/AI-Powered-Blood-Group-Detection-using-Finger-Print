import { Link } from "@tanstack/react-router";
import { Logo } from "@/components/Logo";

type Props = {
  title: string;
  description: string;
};

export function ComingSoon({ title, description }: Props) {
  return (
    <div className="min-h-screen bg-hero text-foreground">
      <header className="mx-auto flex max-w-5xl items-center justify-between px-6 py-6">
        <Link to="/"><Logo /></Link>
        <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">← Home</Link>
      </header>
      <main className="mx-auto max-w-2xl px-6 py-20 text-center">
        <h1 className="font-display text-4xl">{title}</h1>
        <p className="mt-4 text-muted-foreground">{description}</p>
        <div className="mt-8 inline-flex rounded-full border border-border bg-card/60 px-4 py-1.5 text-xs text-muted-foreground">
          Coming soon · BloodScan AI
        </div>
      </main>
    </div>
  );
}
